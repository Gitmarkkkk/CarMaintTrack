# Sprint 1 Plan and Report Draft: CarCare Tracker

Fill in the bracketed items yourself. Everything else is ready to paste into your report.

## A. Project and sprint information

- **Project name:** CarCare Tracker (car maintenance tracker)
- **Sprint number:** 1
- **Name:** [YOUR NAME]
- **Public GitHub repository URL:** [https://github.com/YOUR-USERNAME/YOUR-REPOSITORY]
- **Full commit ID of submitted version:** [output of `git rev-parse HEAD` after your final push]

## B. Sprint Goal and user stories

**Sprint Goal:** Allow a vehicle owner to save their vehicles with model and mileage, see them in a list, and keep each vehicle's mileage up to date.

**Storage:** Data is saved in a local SQLite file (`data/carcare.db`). It remains available after a page refresh and after restarting the application.

### US-01: Add a vehicle

As a vehicle owner, I want to add a vehicle with its make, model and current mileage so that I have a record of the cars I need to maintain.

Acceptance criteria:

1. The owner can enter make, model, current mileage, and optionally a year.
2. Selecting **Add Vehicle** with valid input saves the vehicle.
3. Empty or whitespace-only make or model is rejected with a clear message and nothing is saved.
4. Mileage that is empty, non-numeric or negative is rejected with a clear message and nothing is saved.
5. A year outside 1900 to next year is rejected with a clear message.

Development tasks:

- Create the vehicle entry form.
- Implement server-side validation.
- Create the SQLite table and save vehicles.
- Show success and error messages.
- Check valid and invalid inputs.

Final status: [Completed / Partially Completed / Not Completed]
If incomplete: [unmet criteria]

### US-02: View my vehicles

As a vehicle owner, I want to see all my saved vehicles with their mileage so that I can quickly check what I have recorded.

Acceptance criteria:

1. A newly added vehicle appears in the list showing make, model, year and mileage.
2. The list shows when each vehicle was last updated.
3. When no vehicles exist, a friendly empty message is shown.
4. Saved vehicles remain in the list after refreshing the page and after restarting the application.

Development tasks:

- Query saved vehicles, newest first.
- Build the vehicle list table.
- Add the empty-state message.
- Check refresh and restart behavior.

Final status: [Completed / Partially Completed / Not Completed]
If incomplete: [unmet criteria]

### US-03: Update a vehicle's mileage

As a vehicle owner, I want to update the mileage on a vehicle so that my records stay current as I drive.

Acceptance criteria:

1. Entering a new mileage in a vehicle's row and selecting **Update** saves it and shows the new value.
2. A mileage lower than the current value is rejected with a message that shows both numbers; the saved value is unchanged.
3. An empty or non-numeric mileage is rejected with a clear message.
4. The updated mileage remains after refreshing the page.

Development tasks:

- Add an update form to each list row.
- Implement the update route and validation (no decrease).
- Record the last-updated time.
- Check increases, decreases, and invalid input.

Final status: [Completed / Partially Completed / Not Completed]
If incomplete: [unmet criteria]

## C. Evidence of working functionality (screenshots to take)

Label each screenshot with the story or criterion it shows:

- US-01 criteria 1-2: form filled in, then the vehicle added with the green confirmation.
- US-01 criteria 3-4: empty submit showing red errors; a mileage of `abc` showing its error.
- US-02 criteria 1-2, 4: the list after adding, and again after refreshing.
- US-02 criterion 3: the empty list before any vehicle is added (delete `data/carcare.db` while the server is stopped to get this back).
- US-03 criteria 1-2: a successful update, and the "cannot be lower" error.
- `git log --oneline --graph -n 20` in a readable terminal window.

## D. Acceptance-criteria checks

Run each check yourself and record what you actually see. The "Expected" column is ready; fill in "Actual" and "Pass/Fail". Use a fresh database (delete `data/carcare.db` while the server is stopped) before starting.

| Story | Check performed | Expected result | Actual result | Pass/Fail |
|-------|-----------------|-----------------|---------------|-----------|
| US-01 | Add Toyota / Corolla / 2018 / 64500 | Vehicle appears in list with 64,500 mi and a green message | | |
| US-01 | Submit the form completely empty | Errors for make, model and mileage; nothing added | | |
| US-01 | Make = three spaces, Model = Civic, Mileage = 100 | "Make is required."; nothing added | | |
| US-01 | Mileage = abc | Mileage error; nothing added | | |
| US-01 | Mileage = -5 | Mileage error; nothing added | | |
| US-01 | Year = 1800 | Year error; nothing added | | |
| US-02 | Open the app with no vehicles | Empty-state message shown | | |
| US-02 | Refresh after adding a vehicle | Vehicle still listed | | |
| US-02 | Stop and restart the server, reload | Vehicle still listed | | |
| US-03 | Update mileage from 64500 to 65200 | List shows 65,200 mi and a green message | | |
| US-03 | Update mileage to 60000 (lower) | Error showing both numbers; value stays 65,200 | | |
| US-03 | Submit update with empty mileage | "Mileage is required."; value unchanged | | |
| US-03 | Refresh after an update | New mileage still shown | | |

Known bugs or limitations: [list anything you notice; the README lists the known design limitations]

## Suggested commit sequence

Commit as you genuinely finish and check each piece. The messages below fit the work in this project:

1. `Set up project structure with README and .gitignore`
2. `Create SQLite storage for vehicles`
3. `Create vehicle entry form`
4. `Validate make, model, year and mileage`
5. `Display saved vehicles with empty-state message`
6. `Add mileage update with no-decrease rule`
7. `Document installation, running and Sprint 1 steps`

Before submitting: follow the README from a fresh clone in a separate folder, run `git push`, then `git rev-parse HEAD` for the commit ID.
